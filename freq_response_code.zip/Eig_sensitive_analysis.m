
% clear all
% clc 
    
cd 'current folder' %%% change directory to where case9_modified is stored


mpc= case9_modified
eigs=[];


%%% read dynamic data 
M_g=mpc.M_g;  
D_g= mpc.D_g; 

        %%%%%%%%%% Power flow %%%%%%%%%%%%%%%        
cd 'matpower' %%% change directory to where MATPOWER is installed   
       

     %%%% Run the power flow
       power_flow = runpf(mpc) ;
    
     %%%% Import data from power flow
       test_case=mpc;
       bus_data=power_flow.bus;
       gen_data=power_flow.gen;
       branch_data=test_case.branch;
     
cd 'current folder' %%% change directory to where case9_modified is stored    

    %%%%%%%%%% Network data
     nbus=length(bus_data(:,1));
     bus_name_no=bus_data(:,1);
     bus_type=bus_data(:,2);
	 vbus=bus_data(:,8);
     gens_bus=gen_data(:,1);
     plbus=bus_data(:,3)/100; 
     qlbus=bus_data(:,4)/100; 

    pgbus=zeros(nbus,1);
    for i=1:length(gens_bus)
        gen_bus_array=find(bus_name_no==gens_bus(i));
        pgbus(gen_bus_array)=gen_data(i,2)/100; 
    end

    qgbus=zeros(nbus,1);
    for i=1:length(gens_bus)
        gen_bus_array=find(bus_name_no==gens_bus(i));
        qgbus(gen_bus_array)=gen_data(i,3)/100; 
    end

    %%%%%%%%%%%% Identify Load buses
    load_bus_no_arrays=find(bus_type==1);
    load_bus_no=[];
    for k=1:length(load_bus_no_arrays)
        load_bus_no(k,1)=bus_name_no(load_bus_no_arrays(k));
    end

    %%%%%%%%%%%% Identify Gen buses    Excluding Slack bus
        
    slack_bus_no_array=find(bus_data(:,2)==3);
    slack_bus_no=bus_name_no(slack_bus_no_array);
       
     gen_bus_no_arrays=find(bus_type==2);
     gen_bus_no=[];
     for k=1:length(gen_bus_no_arrays)
         gen_bus_no(k,1)=bus_name_no(gen_bus_no_arrays(k));
     end
    total_gen_bus_no=sort([gen_bus_no; slack_bus_no]);
    Total_buses=size(load_bus_no,1)+ size(gen_bus_no,1)+size(slack_bus_no,1);


     
    %%%%%%%%%%%% create network matrix
	j=sqrt(-1);
    fb=branch_data(:,1);
    tb=branch_data(:,2);
    rb=branch_data(:,3);
    xb=branch_data(:,4); 
    zb=rb+(j*xb); 
    yb = 1./zb;
    branch_no =length(fb); 
    Ybus = zeros(nbus,nbus);
    for k=1:nbus
        i=bus_name_no(k);
        z1=[];z2=[];
       z1=find(tb==i);
       z2=find(fb==i);
       z=union(z1(:),z2(:));
       Ybus(k,k)=sum(yb(z));
    end
    for k=1:branch_no
       z1=find(bus_name_no==fb(k));
       z2=find(bus_name_no==tb(k));
       Ybus(z1,z2)=-yb(k);
       Ybus(z2,z1)=-yb(k);
    end

    [theta,rho]=cart2pol(real(Ybus), imag(Ybus));
    Ybus_mag=rho;
    Ybus_ang=theta;

     %%%%%%%%%%%%%% Kron reduction 
     Y_kroned=zeros(length(total_gen_bus_no),length(total_gen_bus_no));
     Y_temp_new=[];
     Y_temp=Ybus;
     buses_considered=bus_name_no;
     bus_name_no_old=bus_name_no;
     
     reverse_load_buses=flip(load_bus_no); 

     for p=1:length(reverse_load_buses)
         
         eliminated_bus=reverse_load_buses(p);
         buses_considered=setdiff(bus_name_no_old,eliminated_bus);
        for k1=1:length(buses_considered)
            first_bus=k1;
         for k2=1:length(buses_considered)
             second_bus=k2;
                Y_temp_new(k1,k2)=Y_temp(first_bus,second_bus)-((Y_temp(first_bus,eliminated_bus)*Y_temp(eliminated_bus,second_bus))/Y_temp(eliminated_bus,eliminated_bus));
         end
        end
        Y_temp=Y_temp_new;
        bus_name_no_old=buses_considered;
        Y_temp_new=[];
     end
     
     Y_kroned=Y_temp;
     [theta,rho]=cart2pol(real(Y_kroned), imag(Y_kroned));
     Y_kroned_mag=rho;
     Y_kroned_ang=theta;
     gens_total_no=length(gens_bus);
     nbus=length(Y_kroned);
    
    
    %%%%%%% Use  from power flow
     dbus=bus_data(:,9)*pi/180; %degree input and then converted to radian 
         
    %%%%%%%%%%%%%%%% delta_g     
    x_q=0.001;
    I_g=(pgbus(gens_bus)-sqrt(-1)*qgbus(gens_bus))./(vbus(gens_bus).*exp(deg2rad(dbus(gens_bus))*sqrt(-1)));
    dgens=angle(((vbus(gens_bus).*exp(deg2rad(dbus(gens_bus))*sqrt(-1)))+(x_q*sqrt(-1)*I_g)));
    
    steps=1;     
 
for iter=.5:.001:1 %%%% set the parametric variation, for example set iter=.5:.001:1 to observe migration of eigenvalues as a parameter varies between 0.5 and 1
    
    iter_m=iter; %%%% adjust inertia by each iteration
    iter_d=1/iter;    %%%% adjust damping by each iteration

H=[];
for i1=1:nbus
    gen1=total_gen_bus_no(i1);
        for i2=1:nbus
            gen2=total_gen_bus_no(i2);
        if i1~=i2
            H(i1,i2)=vbus(gen1)*vbus(gen2)*(real(Y_kroned(i1,i2))*sin(dgens(gen1)-dgens(gen2))-imag(Y_kroned(i1,i2))*cos(dgens(gen1)-dgens(gen2)));
        end
        end
end

for i1=1:nbus
    H(i1,i1)=-sum(H(i1,:));
end


slackarray=find(total_gen_bus_no==slack_bus_no);

M_g1=M_g;
D_g1=D_g;

M_g1(1)=M_g1(1)*iter_m;
M_g1(2)=M_g1(2)*iter_m;
M_g1(3)=M_g1(3)*iter_m; 

D_g1(1)=D_g1(1)*iter_d;
D_g1(2)=D_g1(2)*iter_d;
D_g1(3)=D_g1(3)*iter_d; 
 

DM_raw1=D_g1./M_g1;

DM_g_nonslack=DM_raw1;
DM_g_nonslack(slackarray)=[];
DM_g_slack=DM_raw1(slackarray);

M_g_nonslack=M_g1;
M_g_nonslack(slackarray)=[];
M_g_slack=M_g1(slackarray);


dn1=[];
      for i=1:length(gen_bus_no)
         gen=gen_bus_no(i);
         genarray=find(gen_bus_no==gen);
         dn1(i,i)=-DM_g_nonslack(genarray);
end
      
hn1=zeros(length(gen_bus_no),length(gen_bus_no));      
    for i=1:length(gen_bus_no)
        gen=gen_bus_no(i);
        total_genarray=find(total_gen_bus_no==gen);
        genarray=find(gen_bus_no==gen);
        H_temp=H(total_genarray,:);
        H_temp(slack_bus_no)=[];
        hn1(i,:)=-H_temp/M_g_nonslack(genarray);
    end
hn=-H(slack_bus_no,:)/M_g_slack;
hn(slack_bus_no)=[];

dn=-DM_g_slack;


%%%% Jacobian
A_jac=[zeros(nbus-1,nbus-1),eye(nbus-1,nbus-1) -ones(nbus-1,1);
      hn1    dn1 zeros(nbus-1,1);
      hn  zeros(1,length(gen_bus_no))  dn];
 
%%%%% Eigenvalues
 jac_eigs=eig(A_jac);
 eigs(steps,:)=[[real(jac_eigs);imag(jac_eigs)]' [iter_m iter_d]];
  
 %%%% Plot eigs
hold on;scatter(real(jac_eigs),imag(jac_eigs))
   
%%%% Dynamic performance metrics
B=zeros(5,1);B(1)=1; %%% to perturb - gen 2 \delta
freqs=[];
for i2=3
C=zeros(1,5);C(i2)=1;          %%% to monitor - gen 2 \omega
D=0; 
    x0 = [0 0 0 0 0]; %initial condition of system states
    system_sim=ss(A_jac,B,C,D);
   [wn,zeta] = damp(system_sim);
end
 oscil_modes=find(zeta~=1);
%   averaged_wn=mean(wn(oscil_modes))
%   averaged_zeta=mean(zeta(oscil_modes))
 
 
%%%%  Frequency response
D=0; 
B=zeros(5,1);B(1)=1; %%% to perturb gen 2 \delta
freqs=[];
for i2=3:4
C=zeros(1,5);C(i2)=1;          %%% to monitor gen 2 \omega
t = 0:0.001:10;  %%%% sim for 10s
        u = .8*ones(1,numel(t)); %step 
    x0 = [0 0 0 0 0]; %initial condition of system states
    system_sim=ss(A_jac,B,C,D);
    [y,x] = lsim(system_sim,u,t,x0); %do the simulation
    freqs(i2,:)=y;
end
freqs(3:4,:)=freqs(3:4,:)/(2*pi);  freqs(3:4,:)=freqs(3:4,:)+60;
hold on; plot(t,freqs(3,:)')
xlim([0 5]); ylim([59.86 60.02])


  %%%%%
  
 steps=steps+1; 
 
end

%%% save eigs in xlsx file
xlswrite('eigs_sensitivity.xlsx',eigs)


