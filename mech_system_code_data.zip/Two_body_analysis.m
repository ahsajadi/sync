

clc

clear all

%%% default values
d1=.35  ;
d2=.35  ;
m1=1    ;
m2=1    ;
k=.3    ;



%%%%% Eigenvalues
fig1=figure
fig2=figure

 for m2=0.001:0.48:1 %%% inertia variation
%   m1=m2             %%% homogeneous vs. heterogeneous inertia
% for d1=0.005:0.17:.35  %%% damping variation
%   d2=d1           %%% homogeneous vs. heterogeneous damping

    A=[
    0 0 1 0;
    0 0 0 1;
    -k/m1 k/m1 -d1/m1 0;
    k/m2 -k/m2 0 -d2/m2
    ];



%%%%%%%%% Computer x1
B=[1;0;0;0];
C=[1 0 0 0];
D=0;
sys = ss(A,B,C,D);
t=0:0.01:100;
x0 = [0 0 0 0];
u(t>=2) = 1;
x1=lsim(sys,u,t,x0);
 
%%%%%%%%% Computer x2
B=[1;0;0;0];
C=[0 1 0 0];
D=0;
sys = ss(A,B,C,D);
t=0:0.01:100;
x0 = [0 0 0 0];
u(t>=2) = 1;
x2=lsim(sys,u,t,x0);
 

%%%%%%%%% Computer x3
B=[1;0;0;0];
C=[0 0 1 0];
D=0;
sys = ss(A,B,C,D);
t=0:0.01:100;
x0 = [0 0 0 0];
u(t>=2) = 1;
x3=lsim(sys,u,t,x0);
 

%%%%%%%%% Computer x4
B=[1;0;0;0];
C=[0 0 0 1];
D=0;
sys = ss(A,B,C,D);
t=0:0.01:100;
x0 = [0 0 0 0];
u(t>=2) = 1;
x4=lsim(sys,u,t,x0);

E=(.5*m1*x3.^2)+(.5*m2*x4.^2);
figure(fig1)
hold on 
plot(t,E,'LineWidth',1.5)
box on
ylabel('kinetic energy')
xlabel('Time [s]')
xlim([0 30])
fig1.Position = [300 300 320 230];

y=(x3);
figure(fig2)
hold on 
plot(t,y,'LineWidth',1.5)
box on
ylabel('speed')
xlabel('Time [s]')
xlim([0 30])
set(gca,'FontSize',11)
fig2.Position = [300 300 320 230];

end



 




