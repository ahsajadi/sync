function [Y_kroned,Kroned_nbus]=MakeKron(x)

mpc=x;

test_case=mpc;


cd 'C:\Users\ahsaj\Documents\MATLAB\matpower6.0'
       

    % %%%% Run the power flow
       power_flow = runpf(mpc) ;
 
       bus_data=power_flow.bus;
       gen_data=power_flow.gen;
     
       
       branch_data=test_case.branch;
 
    %%%%%%%%%% Network data
     nbus=length(bus_data(:,1));
     bus_name_no=bus_data(:,1);
     bus_type=bus_data(:,2);
     vbus=bus_data(:,8);
     gens_bus=gen_data(:,1);
     plbus=bus_data(:,3)/100; 
     qlbus=bus_data(:,4)/100; 

     
     %%%%%%% From power flow
     dbus=bus_data(:,9)*pi/180;  
     
    pgbus=zeros(nbus,1);
    for i=1:length(gens_bus)
        gen_bus_array=find(bus_name_no==gens_bus(i));
        pgbus(gen_bus_array)=gen_data(i,2)/100; 
    end

    qgbus=zeros(nbus,1);
    for i=1:length(gens_bus)
        gen_bus_array=find(bus_name_no==gens_bus(i));
        qgbus(gen_bus_array)=gen_data(i,3)/100; 
    end


    
    %%%%%%%%%%%% Identify Load buses
    load_bus_no_arrays=find(bus_type==1);
    load_bus_no=[];
    for k=1:length(load_bus_no_arrays)
        load_bus_no(k,1)=bus_name_no(load_bus_no_arrays(k));
    end


    %%%%%%%%%%%% Identify Gen buses Excluding Slack bus
    
    
    slack_bus_no_array=find(bus_data(:,2)==3);
    slack_bus_no=bus_name_no(slack_bus_no_array);
        
     gen_bus_no_arrays=find(bus_type==2);
     gen_bus_no=[];
     for k=1:length(gen_bus_no_arrays)
         gen_bus_no(k,1)=bus_name_no(gen_bus_no_arrays(k));
     end


     total_gen_bus_no=sort([gen_bus_no; slack_bus_no]);

     Total_buses=size(load_bus_no,1)+ size(gen_bus_no,1)+size(slack_bus_no,1); 


    %%% Create Network Matrix
     j=sqrt(-1);
    fb=branch_data(:,1);
    tb=branch_data(:,2);
    rb=branch_data(:,3);
    xb=branch_data(:,4); 
    zb=rb+(j*xb); 
    yb = 1./zb;

    branch_no =length(fb); 
    nbus=length(bus_data(:,1));

    Ybus = zeros(nbus,nbus); 
    for k=1:nbus
        i=bus_name_no(k);
        z1=[];z2=[];
       z1=find(tb==i);
       z2=find(fb==i);
       z=union(z1(:),z2(:));
       Ybus(k,k)=sum(yb(z));
    end
 
    for k=1:branch_no
       z1=find(bus_name_no==fb(k));
       z2=find(bus_name_no==tb(k));
       Ybus(z1,z2)=-yb(k);
       Ybus(z2,z1)=-yb(k);
    end
 

    [theta,rho]=cart2pol(real(Ybus), imag(Ybus));
    Ybus_mag=rho;
    Ybus_ang=theta;
    
    
     total_gen_bus_no=sort([gen_bus_no; slack_bus_no]);

     Total_buses=size(load_bus_no,1)+ size(gen_bus_no,1)+size(slack_bus_no,1) ;


     %%%%%%%%%%%%%% Kron reduction  
    
     Y_kroned=zeros(length(total_gen_bus_no),length(total_gen_bus_no));

     Y_temp_new=[];
     Y_temp=Ybus;
     buses_considered=bus_name_no;
     bus_name_no_old=bus_name_no;
     
     reverse_load_buses=flip(load_bus_no); 

     for p=1:length(reverse_load_buses)
         
         eliminated_bus=reverse_load_buses(p);
         buses_considered=setdiff(bus_name_no_old,eliminated_bus);
        for k1=1:length(buses_considered)
            first_bus=k1;
         for k2=1:length(buses_considered)
             second_bus=k2;
                Y_temp_new(k1,k2)=Y_temp(first_bus,second_bus)-((Y_temp(first_bus,eliminated_bus)*Y_temp(eliminated_bus,second_bus))/Y_temp(eliminated_bus,eliminated_bus));
         end
        end
        Y_temp=Y_temp_new;
        bus_name_no_old=buses_considered;
        Y_temp_new=[];
     end
     
     Y_kroned=Y_temp;
     
      [theta,rho]=cart2pol(real(Y_kroned), imag(Y_kroned));
    Y_kroned_mag=rho;
    Y_kroned_ang=theta;
     
    gens_total_no=length(gens_bus);
    
    Kroned_nbus=length(Y_kroned);
    
    