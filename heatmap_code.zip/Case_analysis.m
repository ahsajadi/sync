
% clear all
% clc

    case_run{1}='mpc= case9modified';
    case_run{2}='mpc= case30modified';
    case_run{3}='mpc= case39modified';
    case_run{4}='mpc= case57modified';
    case_run{5}='mpc= case118modified';
    case_run{6}='mpc= case300modified';


  for case_run_no=1:6
      
cd 'current folder' %%%%% change directory where cases are stored


        eval(case_run{case_run_no}); 
  

 for iter=1:1000   %%%% Number of simulations
    

%%%%%%%%%%% Assign random load %%%%%%%%%%%%
original_loads_p=mpc.bus(:,3);
original_loads_q=mpc.bus(:,4);
%%% random loads 
r_range_min_lim = 90;
r_range_max_lim = 100;
r_range = (r_range_max_lim-r_range_min_lim).*rand(100,1) + r_range_min_lim;
rand_arrays=ceil(rand(1,length(original_loads_p))*length(r_range));
rands=r_range(rand_arrays);
new_loads_p=.01*rands.*original_loads_p;
new_loads_q=.01*rands.*original_loads_q;


%%%%%%%%%%% Adjust M and D %%%%%%%%%%   
Hs_raw=[];
DM_raw=[];
H_gMVAed=[];
M_gMVAed=[];
D_gMVAed=[];

%%%% orignial values %%%%%%%%% Common Part
    Hs_raw = mpc.original_Hs';
    H_gMVAed=mpc.MVAs.*Hs_raw';
    DM_raw = mpc.DM_g';
    fs=mpc.fs;
    omega_s=fs*2*pi;
    M_gMVAed=(2*mpc.MVAs.*Hs_raw')/omega_s ;
    D_gMVAed=DM_raw'.*M_gMVAed  ;
    sev=mpc.severity;

    D_gMVAed = rand(1,length(D_gMVAed)).*D_gMVAed' ;
    M_gMVAed = rand(1,length(M_gMVAed)).*M_gMVAed' ;    
    DM_raw=D_gMVAed./M_gMVAed ;
    H_gMVAed=(M_gMVAed*omega_s)./(2*mpc.MVAs)'; 
    
     V_ref_g=mpc.V_ref_g;
     fs=mpc.fs;
     M_g=M_gMVAed;  
     D_g=D_gMVAed; 
     
%%%%%%%%%%%%%%%%%%% Power flow 

     cd 'matpower' %%% change directory to where MATPOWER is installed   

    % %%%% Run the power flow
       power_flow = runpf(mpc) ;
   
    % %%%% Import data from power flow
       test_case=mpc;
       bus_data=power_flow.bus;
       gen_data=power_flow.gen;
       branch_data=test_case.branch;
    
 cd 'current folder' %%%%% change directory where cases are stored

    %%%%%%%%%% Network data
     nbus=length(bus_data(:,1));
     bus_name_no=bus_data(:,1);
     bus_type=bus_data(:,2);
     vbus=bus_data(:,8);
     gens_bus=gen_data(:,1);
     plbus=bus_data(:,3)/100; 
     qlbus=bus_data(:,4)/100;

     
 %%%%%%% From power flow
     dbus=bus_data(:,9)*pi/180; 
     
    pgbus=zeros(nbus,1);
    for i=1:length(gens_bus)
        gen_bus_array=find(bus_name_no==gens_bus(i));
        pgbus(gen_bus_array)=gen_data(i,2)/100; 
    end

    qgbus=zeros(nbus,1);
    for i=1:length(gens_bus)
        gen_bus_array=find(bus_name_no==gens_bus(i));
        qgbus(gen_bus_array)=gen_data(i,3)/100; %100MW pu
    end
    %%%%%%%%%%%% Identify Load buses
    load_bus_no_arrays=find(bus_type==1);
    load_bus_no=[];
    for k=1:length(load_bus_no_arrays)
        load_bus_no(k,1)=bus_name_no(load_bus_no_arrays(k));
    end
   %%%%%%%%%%%% Identify Gen buses Excluding Slack bus
    slack_bus_no_array=find(bus_data(:,2)==3);
    slack_bus_no=bus_name_no(slack_bus_no_array);
        
     gen_bus_no_arrays=find(bus_type==2);
     gen_bus_no=[];
     for k=1:length(gen_bus_no_arrays)
         gen_bus_no(k,1)=bus_name_no(gen_bus_no_arrays(k));
     end

     total_gen_bus_no=sort([gen_bus_no; slack_bus_no]);
     Total_buses=size(load_bus_no,1)+ size(gen_bus_no,1)+size(slack_bus_no,1); 

     
     
    %%%% Kron reduction
    [Y_kroned,Kroned_nbus]=MakeKron(mpc);
    
    
     %%%%%%%%%%%%%%%%%%%%% 
     %%%%%%%%%%%%%%%%%%%%%%
     %%%%%%%%%%%%%%%%%%%%%%

dbus=bus_data(:,9)*pi/180;
x_q=0.05;
I_g=(pgbus(gens_bus)-sqrt(-1)*qgbus(gens_bus))./(vbus(gens_bus).*exp(deg2rad(dbus(gens_bus))*sqrt(-1)));
dgens=angle(((vbus(gens_bus).*exp(deg2rad(dbus(gens_bus))*sqrt(-1)))+(x_q*sqrt(-1)*I_g)));


H=[];
for i1=1:Kroned_nbus
    gen1=total_gen_bus_no(i1);
        for i2=1:Kroned_nbus
            gen2=total_gen_bus_no(i2);
        if i1~=i2
            H(i1,i2)=vbus(gen1)*vbus(gen2)*(real(Y_kroned(i1,i2))*sin(dgens(gen1)-dgens(gen2))-imag(Y_kroned(i1,i2))*cos(dgens(gen1)-dgens(gen2)));
        end
        end
end

for i1=1:Kroned_nbus
    H(i1,i1)=-sum(H(i1,:));
end

slackarray=find(total_gen_bus_no==slack_bus_no);

DM_g_nonslack=DM_raw;
DM_g_nonslack(slackarray)=[];
DM_g_slack=DM_raw(slackarray);

M_g_nonslack=M_g;
M_g_nonslack(slackarray)=[];
M_g_slack=M_g(slackarray);


dn1=[];
      for i=1:length(gen_bus_no)
         gen=gen_bus_no(i);
         genarray=find(gen_bus_no==gen);
         dn1(i,i)=-DM_g_nonslack(genarray);
end
      
hn1=zeros(length(gen_bus_no),length(gen_bus_no));      
    for i=1:length(gen_bus_no)
        gen=gen_bus_no(i);
        total_genarray=find(total_gen_bus_no==gen);
        genarray=find(gen_bus_no==gen);
        H_temp=H(total_genarray,:);
        H_temp(slack_bus_no)=[];
        hn1(i,:)=-H_temp/M_g_nonslack(genarray);
    end
hn=-H(slack_bus_no,:)/M_g_slack;
hn(slack_bus_no)=[];

dn=-DM_g_slack;

A_jac=[zeros(Kroned_nbus-1,Kroned_nbus-1),eye(Kroned_nbus-1,Kroned_nbus-1) -ones(Kroned_nbus-1,1);
      hn1    dn1 zeros(Kroned_nbus-1,1);
      hn  zeros(1,length(gen_bus_no))  dn];
  
 %%%%% eigs and time-domain response ---- system jacobian 
 jac_eigs=eig(A_jac);

 gen_test=1;
 %%%% To Perturb
sys=[];
 A=A_jac;
  B=zeros(length(A_jac),1);B(1:(length(A_jac)/2-.5),1)=1;
%%%% To monitor
    for k=gen_test+((2*Kroned_nbus-1)/2-.5);
C2=zeros(1,length(A_jac));C2(1,k)=1;
    D=0;
    t = 0:.1:400; 
    amp_tmp=sev;
    u = amp_tmp*ones(1,numel(t)); %step disturbance
    x0 = zeros(1,length(A_jac)); %initial condition of system states
    system_sim=ss(A,B,C2,D);
    [y,x] = lsim(system_sim,u,t,x0); %do the simulation
    clear freq
    freq=y/(2*pi); freq=freq+60;
    devs=abs(y);
    freq_diff=diff(freq);
    settling_freq_arrays=find(abs(freq_diff)<0.0000001);
    settling_freq_array=min(settling_freq_arrays);
    settling_time=t(settling_freq_array);
    hertz_sec_value(iter)=trapz(devs(1:settling_freq_array));
    end

    Ms(iter)=M_gMVAed(gen_test+1);
    Ds(iter)=D_gMVAed(gen_test+1); 

    
end
 
%%%%%%%%%%%%%% Nadir Heat Map 

figure;

x=Ds;
y=Ms;
z=log(hertz_sec_value);


z_arrays=min(z):(max(z)-min(z))/6:max(z);
for i=1:length(z) 
     if z(i)>=z_arrays(6) %color_code1>0&color_code1<=1/6 %% Red
        color_code2=[1,0,0];
    elseif z(i)<z_arrays(6) & z(i)>=z_arrays(5) %color_code1>1/6&color_code1<=2/6 %% Orange
        color_code2=[.9865, 0.737, 0.250];
    elseif  z(i)<z_arrays(5) & z(i)>=z_arrays(4) %color_code1>2/6&color_code1<=3/6 %% Yellow
        color_code2=[.9763,.9831,.0538];
    elseif  z(i)<z_arrays(4) & z(i)>=z_arrays(3) %color_code1>3/6&color_code1<=4/6 %% Green
        color_code2=[0,1,0];
    elseif  z(i)<z_arrays(3) & z(i)>=z_arrays(2) %color_code1>4/6&color_code1<=5/6 %% Cyan
        color_code2=[0.196,.7214,.6310];
    elseif  z(i)<=z_arrays(2) %color_code1>5/6&color_code1<=6/6 %% Blue
        color_code2=[0, 0, 1];
    end

hold on
h1=plot(x(i),y(i),'-o','MarkerSize',3, 'color',color_code2);
set(h1, 'markerfacecolor', get(h1, 'color'))
grid on
end

test_case_name=length(mpc.bus(:,1))
titlename=sprintf('%d Bus System',test_case_name);
 title(titlename)
 xlabel('Damping');
 ylabel('Inertia');
 


end
